### PROCESO DE INSTALACION
Instala los archivos necesarios
```bash
- termux-setup-storage
- pkg upgrade && update
- pkg install nodejs -y
- pkg install git -y
- pkg install bash -y
```

Clona este repositorio
 ```bash
> git clone https://github.com/ByTraxnox2/bytraxnox_bot
```

Inicia la instalacion
```bash
- cd bytraxnox_bot
- bash install.sh
```

Para Iniciar el Bot
 ```bash
- npm start
```